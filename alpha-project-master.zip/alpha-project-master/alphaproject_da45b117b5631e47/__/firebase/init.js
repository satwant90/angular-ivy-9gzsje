if (typeof firebase === 'undefined') throw new Error('hosting/init-error: Firebase SDK not detected. You must include it before /__/firebase/init.js');
firebase.initializeApp({
  "apiKey": "AIzaSyCK33IzBFHgK8ylZuv_7_BHaSsFG1mzIns",
  "appId": "1:542791244569:web:44632575874123918a8388",
  "authDomain": "alpha-project-lorenzoni.firebaseapp.com",
  "databaseURL": "",
  "measurementId": "G-KG7L64YL3R",
  "messagingSenderId": "542791244569",
  "projectId": "alpha-project-lorenzoni",
  "storageBucket": "alpha-project-lorenzoni.appspot.com"
});