export interface Timestamp {
    nanoseconds: number;
    seconds: number;
}
