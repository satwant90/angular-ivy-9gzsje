export const USER_NAV = [
    {
        url: '/dashboard',
        name: 'Home',
        icon: 'houseFill',
        isHome: true
    },
    {
        url: '/dashboard/workout',
        name: 'WorkOut',
        icon: 'lightningFill',
        isWorkout: true,
    },
    {
        url: '/dashboard/video',
        name: 'Video',
        icon: 'cameraVideoFill',
    },
];
